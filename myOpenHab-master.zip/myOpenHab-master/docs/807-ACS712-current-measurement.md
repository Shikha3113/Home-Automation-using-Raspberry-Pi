# ACS712 Current Sensor


http://arduinotronics.blogspot.co.za/2015/07/arduino-acs712-current-sensor.html?m=1
