# GSM / GPRS / 3G networks

https://www.openhomeautomation.net/monitor-data-arduino-fona/


    Hi Nelis
    Die link wat ek gekry het werk nie. Ek het egter die gsm module aan die werk. Glad nie soos geadverteer nie.    
    1.  Externe supply werk nie reg via sok nie. Gebruik die 5v insette vanaf externe supply.
    2.  Sw serial werk nie, moet hw serial gebruik.
    3.  power on reset 12 sek in plaas van die 2 sek wat hulle se.
    Verder werk hy nou redelik goed sonder enige ander veranderlikes.  
    Louis van der Merwe

------------------------
https://www.cooking-hacks.com/documentation/tutorials/gprs-gsm-quadband-module-arduino-raspberry-pi-tutorial-sim-900/
