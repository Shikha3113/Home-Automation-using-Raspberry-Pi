# Energy and Power Measurement


http://arduinotronics.blogspot.co.za/2016/02/ac-current-monitoring-current.html?m=1

http://www.butlerwinding.com/current-transformers-theory-operation/
