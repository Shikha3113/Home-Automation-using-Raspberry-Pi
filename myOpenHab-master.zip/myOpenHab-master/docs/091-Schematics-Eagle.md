# Schematics with Eagle Free Version
## Download

## Additional parts
https://github.com/sparkfun/SparkFun-Eagle-Libraries  
http://www.cadsoftusa.com/downloads/libraries   
http://electronics.stackexchange.com/questions/38896/how-to-easily-find-or-create-parts-for-eagle-schematic-board-layout    
http://www.diymodules.org/eagle    
http://www.jaglarz.info/ja/elektronika/eagle/biblioteki.php  


## Loading libraries
https://learn.sparkfun.com/tutorials/how-to-install-and-setup-eagle/using-the-sparkfun-libraries

## Adding parts
http://www.instructables.com/id/How-to-make-a-custom-library-part-in-Eagle-CAD-too/
http://www.hcilab.org/resources/boardlayout/eagle-librarydesign.htm
http://www.sparkfun.com/tutorials/110


## Using Eagle
https://learn.sparkfun.com/tutorials/using-eagle-schematic  
https://learn.sparkfun.com/tutorials/using-eagle-board-layout  
https://learn.sparkfun.com/tutorials/designing-pcbs-advanced-smd  
