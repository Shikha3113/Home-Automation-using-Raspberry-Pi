# DHT11/DHT22 Humidity and Temperature Sensor


https://learn.adafruit.com/dht?view=all

<http://randomnerdtutorials.com/complete-guide-for-dht11dht22-humidity-and-temperature-sensor-with-arduino/>

https://github.com/gonium/esp8266-dht22-sensor

https://arduino-info.wikispaces.com/DHT11-Humidity-TempSensor

http://labs.arduino.org/Arduino+UNO+DHT11+Temperature+and+Humidity+Sensor+Example


Interrupt-driven library
https://github.com/niesteszeck/idDHT11

http://www.esp8266.com/viewtopic.php?f=19&t=2029

http://playground.arduino.cc/Main/DHT11Lib

https://github.com/adafruit/DHT-sensor-library
