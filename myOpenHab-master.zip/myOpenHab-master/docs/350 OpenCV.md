# OpenCV

http://www.pyimagesearch.com/2016/02/29/saving-key-event-video-clips-with-opencv/

http://funvision.blogspot.co.za/2016/03/opencv-31-pedestrian-people-detection.html?m=1

http://robocv.blogspot.co.za/2012/01/using-your-ip-camera-with-opencv.html?m=1
