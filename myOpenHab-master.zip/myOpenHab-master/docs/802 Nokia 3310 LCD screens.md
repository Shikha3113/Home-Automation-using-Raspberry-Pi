# Nokia 3310 screens

http://www.instructables.com/id/Salvaging-a-NOKIA-3310-LCD-and-using-it-with-Ardui/?ALLSTEPS
