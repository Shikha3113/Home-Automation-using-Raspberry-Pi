# DS2413 1-Wire Switch

<https://learn.adafruit.com/adafruit-1-wire-gpio-breakout-ds2413/onewire-library>

<http://www.pjrc.com/teensy/td_libs_OneWire.html>

<https://www.adafruit.com/products/1551>

