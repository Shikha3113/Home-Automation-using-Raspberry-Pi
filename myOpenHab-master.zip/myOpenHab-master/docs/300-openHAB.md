# openHAB

more detail to follow



http://jpmens.net/2014/01/14/a-story-of-home-automation/

http://www.element14.com/community/community/design-challenges/forget-me-not/blog/2014/09/17/fmnxx-mqtt--the-language-of-iot

## openHAB / RPi Project

<http://makezine.com/projects/building-a-home-automation-system-with-openhab-to-control-leds-wirelessly/>

Using the open source software openHAB, we’ll be building a Raspberry Pi touchscreen command center that can interface with over 150 different “smart home” products, and provide an interface for control and task scheduling. Instead of using an existing product though, we’ll build our own WiFi enabled RGB LED strip that interfaces with OpenHAB, allowing you to wirelessly control it from your smartphone or any computer on your network.
