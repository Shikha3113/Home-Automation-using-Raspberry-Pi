# OWFS

<http://playground.arduino.cc/Learning/OneWire>


<http://www.teensypi.com/>

<http://owfs.org/index.php?page=raspberry-pi>

<http://owfs.org/index.php?page=what-is-1-wire>

<https://www.raspberrypi.org/forums/viewtopic.php?f=37&t=7713>

<https://translate.google.com/translate?hl=en&sl=de&u=http://www.mikrocontroller.net/topic/288813&prev=search>

<http://owfs.sourceforge.net/owpython.html>

<https://www.raspberrypi.org/forums/viewtopic.php?f=26&t=9188>

<http://wiki.m.nu/index.php/OWFS_with_i2c_support_on_Raspberry_Pi_%28English_version%29>

<http://www.astounding.org.uk/ian/raspi-1wire/>

<http://simplyautomationized.blogspot.com/2014/02/home-automation-project-4-1-wire-io.html>

<http://www.axiris.eu/download/owsas/1.1.0/owsas_v1_1_0_sg_en_us_2015_06_16.pdf>

<http://www.axiris.eu/en/index.php/1-wire/1-wire-automation-software/documents-and-software>

<http://www.axiris.eu/en/index.php/1-wire/10-additional-content>

<http://raspberrypi.stackexchange.com/questions/1835/can-i-use-a-one-wire-file-system-through-the-gpio>

<http://www.homautomation.org/2015/01/22/expand-arduino-io-with-1wire-ds2408/>

<http://www.instructables.com/id/Home-automation-project-based-on-1-wire-devices/>

<http://www.maximintegrated.com/en/products/interface/controllers-expanders/DS2413.html>

