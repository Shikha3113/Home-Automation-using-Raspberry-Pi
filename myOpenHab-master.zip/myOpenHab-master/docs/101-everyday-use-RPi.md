# Day-to-Day Raspberry Use

## Shutting down RPi

<http://raspi.tv/2012/how-to-safely-shutdown-or-reboot-your-raspberry-pi>  

	sudo shutdown -h now
	sudo reboot -h now

