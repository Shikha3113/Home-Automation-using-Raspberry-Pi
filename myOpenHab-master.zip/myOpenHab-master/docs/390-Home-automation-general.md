# Home automation - general

http://randomnerdtutorials.com/9-home-automation-open-source-platforms-for-your-projects/

https://pidome.org/features/server-features.html

http://www.mycontroller.org/#/home

