# Garage door openers

https://www.hackster.io/JoeTio/overkill-genie-garage-door-opener-92a2d3

https://www.hackster.io/szormpas/echogarage-b712f8

http://vidieukhien.xyz/en_US/iot-do-khoang-cach-phat-hien-xe-trong-gara-su-dung-node-mcuesp8266-cam-bien-sieu-am/

http://www.whiskeytangohotel.com/2017/01/esp8266-wifi-garage-door-opener-from.html

https://www.hackster.io/kayakpete/esp8266-wifi-smart-garage-door-e08013

http://www.plastibots.com/index.php/2015/06/11/iot-garage-monitor-with-finger-print-sensor/

