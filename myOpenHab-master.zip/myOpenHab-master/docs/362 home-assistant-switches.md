# Home Assistant Switches


## Sonoff and Slampher

See https://github.com/NelisW/myOpenHab/blob/master/docs/809-ITead-Studio.md


