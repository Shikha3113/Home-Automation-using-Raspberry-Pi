# REST

http://www.survivingwithandroid.com/2016/05/arduino-rest-api-iot.html


https://create.arduino.cc/projecthub/wesee/control-your-mkr1000-with-arest-framework-ba6619
