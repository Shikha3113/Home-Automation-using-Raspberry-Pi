# Schematics with Fritzing


Fritzing is a real paint to use, I am trying to see if I can use Eagle.


## Download

## Additional parts

- https://github.com/adafruit/Fritzing-Library/tree/master/parts
- http://www.elec-cafe.com/fritzing-parts-download/


## Your local parts
 %USER%\AppData\Roaming\Fritzing\bins
 %USER%\AppData\Roaming\Fritzing\parts\user.  
copy the new parts into this directory and then import the part into your diagram using the part import menu at the top right, just above the parts inventory.
