# HC-SR04 Ultrasonic Sensor

http://uglyduck.ath.cx/ep/archive/2014/01/Making_a_better_HC_SR04_Echo_Locator.html

http://www.instructables.com/id/Hc-sr04-Ultrasonic-Distance-Sensor/?ALLSTEPS

https://bitbucket.org/teckel12/arduino-new-ping/wiki/Home

http://www.instructables.com/id/Easy-ultrasonic-4-pin-sensor-monitoring-hc-sr04/?ALLSTEPS

http://www.instructables.com/id/Simple-Arduino-and-HC-SR04-Example/?ALLSTEPS



http://pythonhackers.com/p/eadf/esp8266_ping

https://github.com/loiphin/ESP8266

https://github.com/sza2/node_hcsr04

http://randomnerdtutorials.com/complete-guide-for-ultrasonic-sensor-hc-sr04/

http://stackoverflow.com/questions/32428274/nodemcu-esp8266-hc-sr04-tmr-now-difference-is-incorrect

http://www.esp8266.nu/forum/viewtopic.php?t=57

http://letsmakerobots.com/blog/jscottb/esp8266-running-nodemcu-a-controller

http://www.instructables.com/id/OpenHab-Arduino/?ALLSTEPS

http://www.esp8266.com/viewtopic.php?f=11&t=1503


