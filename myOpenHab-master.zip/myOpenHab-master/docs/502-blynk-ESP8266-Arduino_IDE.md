# Using Blynk natively on ESP8266 with Arduino IDE

<http://www.blynk.cc/>


<http://community.blynk.cc/t/hardware-supported-by-blynk/16>


[Adafruit HUZZAH ESP8266 Standalone Stops working after half an hour](http://community.blynk.cc/t/adafruit-huzzah-esp8266-standalone-stops-working-after-half-an-hour/1828)



## node-red for blynk

http://nodered.org/  

https://www.npmjs.com/package/node-red-contrib-blynk