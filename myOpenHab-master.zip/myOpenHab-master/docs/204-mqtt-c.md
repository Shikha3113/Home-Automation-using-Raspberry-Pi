# MQTT in C

http://www.eclipse.org/paho/files/mqttdoc/Cclient/

https://www.eclipse.org/paho/files/mqttdoc/Casync/index.html

https://github.com/eclipse/paho.mqtt.c

For the ESP8266  

https://github.com/tuanpmt/esp_mqtt  
https://nathan.chantrell.net/20141230/wifi-mqtt-display-with-the-esp8266/


