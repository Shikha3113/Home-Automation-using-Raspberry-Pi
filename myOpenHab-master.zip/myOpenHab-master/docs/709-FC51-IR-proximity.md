# FC51-IR-proximity


    Model Number: FC-51
    Detection angle: 35 °
    Operating Voltage: 3.0V – 6.0V
    Detection range: 2cm – 30cm (Adjustable using potentiometer)
    pcb size : 3.1 cm (L) x 1.4 cm (W)
    Overall Dimension: 4.5cm (L) x 1.4 cm (W), 0.7cm (H)
    Ative output level: Outputs Low logic level when obstacle is detected
    In-active output level: Outputs High logic level when obstacle is not detected
    Current Consumption:
        at 3.3V : ~23 mA
        at 5.0V: ~43 mA



http://www.playembedded.org/blog/en/2016/01/08/detecting-obstacle-with-ir-sensor-and-arduino/

http://artofcircuits.com/product/infrared-obstacle-avoidance-proximity-sensors-module-fc-51

http://playground.arduino.cc/Main/PanasonicIrSensor

