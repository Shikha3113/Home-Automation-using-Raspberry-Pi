# ESP8266 Arduino

## ESP8266 Arduino framework

https://github.com/esp8266/Arduino

https://github.com/esp8266/Arduino/blob/master/doc/filesystem.md

## ESP8266 as Arduino shield

### YAAB

http://yaab-arduino.blogspot.co.za/2015/12/cheap-arduino-wifi-shield-with-esp8266.html
http://yaab-arduino.blogspot.co.za/p/wifiesp.html
http://yaab-arduino.blogspot.co.za/2015/05/esp8266-wifi-library.html
https://github.com/bportaluri/WiFiEsp
http://www.instructables.com/id/Cheap-Arduino-WiFi-Shield-With-ESP8266/

### Forward Computing
ESP8266-01  
http://www.forward.com.au/pfod/CheapWifiShield/ESP2866_01_WiFi_Shield/index.html  
http://www.forward.com.au/pfod/ESP8266/GPIOpins/ESP8266_01_pin_magic.html

HUZZAH:   
http://www.forward.com.au/pfod/CheapWifiShield/index.html

### DOIT
https://fineshang.gitbooks.io/esp8266-based-serial-wifi-shield-for-arduino-user/content/index.html
https://www.tindie.com/products/doit/arduino-uno-r3-esp8266-wireless-wifi-shield/
http://www.doit.am/
https://fineshang.gitbooks.io/esp8266-based-serial-wifi-shield-for-arduino-user/content/index.html
http://www.smartarduino.com/esp8266-wifi-web-sever-shield-for-arduino_p94660.html

### contractorwolf

https://github.com/contractorwolf/ESP8266/blob/master/ESP8266.ino
http://contractorwolf.com/esp8266-wifi-arduino-micro/

### Other

http://www.instructables.com/id/ESP8266-WiFi-Shield-for-Arduino-and-other-micros

http://www.instructables.com/id/Connect-to-Blynk-using-ESP8266-as-Arduino-Uno-wifi/

https://www.hackster.io/nolan-mathews/connect-to-blynk-using-esp8266-as-arduino-uno-wifi-shield-m1-46a453

http://arduino.stackexchange.com/questions/18903/connecting-esp8266-with-arduino-uno-wifi-shield-not-present

https://github.com/ekstrand/ESP8266wifi

http://dalpix.com/blog/connecting-your-arduino-wifi-esp-8266-module
