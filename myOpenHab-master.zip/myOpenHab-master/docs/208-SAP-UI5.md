# SAP UI5

http://openui5.org/

https://github.com/jpenninkhof/espardu_devicex/blob/master/src/main.ino

http://www.penninkhof.com/2016/04/minimizing-ui5-apps-footprint-to-run-from-an-esp8266/
