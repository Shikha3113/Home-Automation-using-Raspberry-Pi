 # BMP180 BMP085 Pressure and Temperature Sensor


## Device overview

https://www.adafruit.com/products/1603

https://learn.sparkfun.com/tutorials/bmp180-barometric-pressure-sensor-hookup-



## Libraries
### platformio

http://platformio.org/lib/show/578/Sensors

https://github.com/loopj/i2c-sensor-hal

See the instructions for ESP8266 [here]()

### Others
https://github.com/sparkfun/BMP180_Breakout

https://github.com/adafruit/Adafruit-BMP085-Library
