# RF communications technologies



to follow.

http://www.buildcircuit.com/how-to-use-rf-module-with-arduino/
https://www.pjrc.com/teensy/td_libs_VirtualWire.html
http://www.instructables.com/id/RF-315433-MHz-Transmitter-receiver-Module-and-Ardu/?ALLSTEPS
http://www.instructables.com/id/RF-315433-MHz-Transmitter-receiver-Module-and-Ardu/?ALLSTEPS

http://randomnerdtutorials.com/nrf24l01-2-4ghz-rf-transceiver-module-with-arduino/

## ESP8266

## RF69

<http://www.hoperf.com/rf/fsk_module/RFM69HCW.htm>  
<https://hallard.me/bp-ulpnode/>  
<http://lowpowerlab.com/blog/2013/06/20/rfm69-library/>  

## RF24

<https://arduino-info.wikispaces.com/Nrf24L01-2.4GHz-HowTo>  
<http://www.homeautomationforgeeks.com/project/rf24software.shtml>  
<https://tmrh20.github.io/>  
<https://maniacbug.github.io/RF24Network/>  

<http://randomnerdtutorials.com/nrf24l01-2-4ghz-rf-transceiver-module-with-arduino/>